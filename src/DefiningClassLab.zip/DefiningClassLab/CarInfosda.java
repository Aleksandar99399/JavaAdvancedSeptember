package DefiningClassLab;

public class CarInfosda {
    public static void main(String[] args) {
        Car firstCar=new Car();
        Car secondCar=new Car();

        firstCar.make="audi";
        secondCar.make="Mercedes";
        firstCar.model="A4";
        secondCar.model="G55";
        firstCar.horsepower=131;
        secondCar.horsepower=254;


    }
}
